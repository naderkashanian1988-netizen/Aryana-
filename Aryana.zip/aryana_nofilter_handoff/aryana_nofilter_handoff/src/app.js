const svg=document.querySelector('#hotspots'), NS='http://www.w3.org/2000/svg';
async function init(){
 const response=await fetch('./src/icon-registry.json');
 if(!response.ok) throw new Error('Could not load icon registry');
 const registry=await response.json();
 for(const icon of registry.icons){
  if(!icon.hotspot) continue; // Calibrate to the exact reference image before enabling.
  const {x,y,width,height}=icon.hotspot, rect=document.createElementNS(NS,'rect');
  for(const [k,v] of Object.entries({x:x*registry.referenceImage.width,y:y*registry.referenceImage.height,width:width*registry.referenceImage.width,height:height*registry.referenceImage.height,rx:10,class:'hotspot',tabindex:0,role:'button'})) rect.setAttribute(k,String(v));
  rect.setAttribute('aria-label',icon.purpose); rect.dataset.iconId=icon.id;
  const activate=()=>{if(icon.action==='reset') location.reload(); else if(icon.action==='exit'){dispatchEvent(new CustomEvent('aryana:exit-requested')); window.close();} else if(icon.destination) window.open(icon.destination,'_blank','noopener,noreferrer');};
  rect.addEventListener('click',activate); rect.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activate();}});
  svg.appendChild(rect);
 }
 console.info(`Aryana loaded: ${registry.icons.length} action records.`);
}
init().catch(e=>console.error('Aryana initialization failed:',e));
