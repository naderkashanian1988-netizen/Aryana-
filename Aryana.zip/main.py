#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only inspector for Aryana project folders."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", "env", "dist", "build"}
EXTENSIONS = {".html", ".htm", ".js", ".mjs", ".cjs", ".py", ".json", ".css", ".zip", ".md", ".txt", ".toml", ".yaml", ".yml"}
MAX_BYTES = 25 * 1024 * 1024


def read_text(path):
    for enc in ("utf-8", "utf-8-sig", "cp1252"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            pass
    return path.read_text(encoding="utf-8", errors="replace")


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def collect(root):
    out = []
    for base, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in names:
            p = Path(base) / name
            if p.suffix.lower() in EXTENSIONS:
                try:
                    if p.stat().st_size <= MAX_BYTES:
                        out.append(p)
                except OSError:
                    pass
    return sorted(out, key=lambda p: str(p).lower())


def check_py(p):
    try:
        compile(read_text(p), str(p), "exec")
        return "PASS: syntax OK"
    except SyntaxError as e:
        return f"FAIL: line {e.lineno}: {e.msg}"
    except Exception as e:
        return f"SKIP: {e}"


def check_js(p, node):
    if not node:
        return "SKIP: Node.js not installed"
    try:
        r = subprocess.run([node, "--check", str(p)], capture_output=True, text=True, timeout=20)
        if r.returncode == 0:
            return "PASS: syntax OK"
        return "FAIL: " + (r.stderr or r.stdout).strip().replace("\\n", " ")[:400]
    except Exception as e:
        return f"SKIP: {e}"


def check_json(p):
    try:
        json.loads(read_text(p))
        return "PASS: valid JSON"
    except json.JSONDecodeError as e:
        return f"FAIL: line {e.lineno}, column {e.colno}: {e.msg}"
    except Exception as e:
        return f"SKIP: {e}"


def check_html(p):
    s = read_text(p).lower()
    problems = []
    if "<html" not in s:
        problems.append("missing <html> tag")
    if "<script" in s and "</script>" not in s:
        problems.append("possible unclosed script tag")
    if "<style" in s and "</style>" not in s:
        problems.append("possible unclosed style tag")
    if "file://" in s:
        problems.append("contains file:// reference")
    return "BASIC PASS (not a browser test)" if not problems else "CHECK: " + "; ".join(problems)


def main():
    ap = argparse.ArgumentParser(description="Read-only Aryana project inspection")
    ap.add_argument("folder", nargs="?", default=".", help="Project folder (default: current folder)")
    ap.add_argument("--report-dir", help="Report destination (default: project folder)")
    args = ap.parse_args()
    root = Path(args.folder).expanduser().resolve()
    if not root.is_dir():
        print(f"ERROR: folder not found: {root}", file=sys.stderr)
        return 2
    report_dir = Path(args.report_dir).expanduser().resolve() if args.report_dir else root
    try:
        report_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"ERROR: cannot create report folder: {e}", file=sys.stderr)
        return 2

    files = collect(root)
    node = shutil.which("node")
    lines = [
        "ARYANA PROJECT INSPECTION REPORT", "=" * 34,
        "Date: " + datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"),
        f"Project folder: {root}", f"Files scanned: {len(files)}",
        f"Python: {sys.version.split()[0]}", f"Node.js: {node or 'not found'}",
        "", "READ-ONLY CHECK. No project files are changed or deleted.",
        "Static checks do not prove that the app works on a real device.",
        "", "1) FILE INVENTORY", "-" * 34
    ]
    counts = defaultdict(int)
    same_names = defaultdict(list)
    for p in files:
        counts[p.suffix.lower()] += 1
        same_names[p.name.lower()].append(p)
        try:
            lines.append(f"{p.relative_to(root)} | {p.stat().st_size} bytes | SHA256 {sha256(p)}")
        except OSError as e:
            lines.append(f"{p.relative_to(root)} | READ ERROR: {e}")
    lines.extend(["", "Counts by extension:"])
    for ext, count in sorted(counts.items()):
        lines.append(f"  {ext}: {count}")

    lines.extend(["", "2) AUTOMATED CHECKS", "-" * 34])
    for p in files:
        ext = p.suffix.lower()
        result = None
        if ext == ".py":
            result = check_py(p)
        elif ext in {".js", ".mjs", ".cjs"}:
            result = check_js(p, node)
        elif ext == ".json":
            result = check_json(p)
        elif ext in {".html", ".htm"}:
            result = check_html(p)
        if result:
            lines.append(f"{p.relative_to(root)}: {result}")

    lines.extend(["", "3) SAME-NAME FILES / POSSIBLE VERSIONS", "-" * 34])
    duplicates = [(name, paths) for name, paths in sorted(same_names.items()) if len(paths) > 1]
    if not duplicates:
        lines.append("No exact same-name files found. Differently named versions may still exist.")
    else:
        for name, paths in duplicates:
            lines.append(name + ":")
            for p in paths:
                lines.append("  - " + str(p.relative_to(root)))

    lines.extend([
        "", "4) LIMITATIONS", "-" * 34,
        "- HTML checks are basic heuristics, not full browser validation.",
        "- ZIP files are listed but not extracted or modified.",
        "- External websites, APIs, login, and phone behavior are not tested.",
        "- Review this report and keep a backup before any manual edits."
    ])
    report = "\\n".join(lines) + "\\n"
    out = report_dir / f"aryana_inspection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        out.write_text(report, encoding="utf-8")
    except OSError as e:
        print(f"Could not save report: {e}", file=sys.stderr)
        print(report)
        return 2
    print(report)
    print(f"Report saved to: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())