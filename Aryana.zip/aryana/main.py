
import random
import time

accounts = ["Account 1", "Account 2", "Account 3"]
max_usage_per_account = 3

current_account = 0
usage_count = 0

print("Smart Engine - Simulation Mode")
print("Simulation only; no real phone actions.")

for step in range(12):
    account = accounts[current_account]
    action = random.choice(["Swipe", "Tap", "Wait"])

    print(f"[SIMULATION] {account}: {action}")
    usage_count += 1
    time.sleep(0.5)

    if usage_count >= max_usage_per_account:
        print(f"{account} reached its test limit.")
        current_account = (current_account + 1) % len(accounts)
        usage_count = 0
        print(f"Switching to {accounts[current_account]}")

print("Simulation finished.")